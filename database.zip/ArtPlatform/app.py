from flask import Flask, render_template, request, redirect, url_for, session
import mysql.connector
import hashlib
import os

app = Flask(__name__)
app.secret_key = 'rxmn'  # Needed for session management

# Database configuration
def get_db_connection():
    connection = mysql.connector.connect(
        host="localhost",
        user="Ramninder",
        password="rxmn7770",
        database="ArtPlatform"
    )
    return connection

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        # Connect to the database
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM User WHERE Email=%s", (email,))
        user = cursor.fetchone()

        if user:
            # Verify password
            stored_password = user['Password']
            if password == stored_password:  
           
                session['user_id'] = user['UserID']
                session['role'] = user['Role']
                if user['Role'] == 'Artist':
                    return redirect(url_for('artist_dashboard'))
                else:
                    return redirect(url_for('buyer_dashboard'))
            else:
                return "Invalid credentials"
        else:
            return "Invalid credentials"

    return render_template('login.html')


@app.route('/artist_dashboard')
def artist_dashboard():
    if 'user_id' in session and session['role'] == 'Artist':
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM Artwork WHERE ArtistID=%s", (session['user_id'],))
        artworks = cursor.fetchall()
        return render_template('artist_dashboard.html', artworks=artworks)
    else:
        return redirect(url_for('login'))

from flask import request, render_template, redirect, url_for, session
import mysql.connector

@app.route('/buyer_dashboard')
def buyer_dashboard():
    if 'user_id' in session and session['role'] == 'Buyer':
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)

        # Get filter parameters
        min_price = request.args.get('min_price', type=float)
        max_price = request.args.get('max_price', type=float)
        style = request.args.get('style')
        medium = request.args.get('medium')

        # Build the SQL query with filters
        query = "SELECT ArtworkID, Title, Price, Image FROM Artwork WHERE Availability >= 1"
        filters = []
        if min_price is not None:
            filters.append(f"Price >= {min_price}")
        if max_price is not None:
            filters.append(f"Price <= {max_price}")
        if style:
            filters.append(f"Style = '{style}'")
        if medium:
            filters.append(f"Medium = '{medium}'")

        if filters:
            query += " AND " + " AND ".join(filters)

        # Execute the query
        cursor.execute(query)
        artworks = cursor.fetchall()
        cursor.close()
        connection.close()
        return render_template('buyer_dashboard.html', artworks=artworks)
    else:
        return redirect(url_for('login'))

    
@app.route('/artist/<int:artist_id>')
def artist_page(artist_id):
    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)

    try:
        # Fetch artist details
        cursor.execute("SELECT * FROM Artist JOIN User ON Artist.ArtistID = User.UserID WHERE ArtistID = %s", (artist_id,))
        artist = cursor.fetchone()

        # Fetch artworks by this artist
        cursor.execute("SELECT * FROM Artwork WHERE ArtistID = %s", (artist_id,))
        artworks = cursor.fetchall()

    except mysql.connector.Error as err:
        return f"Error: {err}"
    finally:
        cursor.close()
        connection.close()

    if not artist:
        return "Artist not found", 404

    return render_template('artist_page.html', artist=artist, artworks=artworks)



   
@app.route('/buyer_order_details')
def buyer_order_details():
    if 'user_id' in session and session['role'] == 'Buyer':
        user_id = session['user_id']
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT o.OrderID, o.OrderDate, o.TotalAmount, o.Status, p.PaymentMethod, oi.ArtworkID, a.Title, oi.Quantity, oi.Price
            FROM `order` o
            JOIN orderitem oi ON o.OrderID = oi.OrderID
            JOIN Artwork a ON oi.ArtworkID = a.ArtworkID
            LEFT JOIN payment p ON o.OrderID = p.OrderID
            WHERE o.BuyerID = %s
            ORDER BY o.OrderDate DESC
        """, (user_id,))
        orders = cursor.fetchall()

        cursor.close()
        connection.close()

        return render_template('buyer_order_details.html', orders=orders)
    else:
        return redirect(url_for('login'))
    
@app.route('/artwork/<int:artwork_id>', methods=['GET', 'POST'])
def artwork_detail(artwork_id):
    if 'user_id' in session:
        user_id = session['user_id']
        
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        
        # Get artwork details
        cursor.execute("""
            SELECT a.Title, a.Description, a.Price, a.Image, a.Medium, a.Style, a.Availability, a.ArtistID, a.ArtworkID
            FROM Artwork a
            WHERE a.ArtworkID = %s
        """, (artwork_id,))
        artwork = cursor.fetchone()
        
        if artwork is None:
            return redirect(url_for('buyer_dashboard'))  # Redirect if artwork not found

        # Get reviews for the artwork
        cursor.execute("""
            SELECT r.Rating, r.Comment, r.ReviewDate, u.Name
            FROM Review r
            JOIN User u ON r.BuyerID = u.UserID
            WHERE r.ArtworkID = %s
        """, (artwork_id,))
        reviews = cursor.fetchall()

        # Handle add to cart or buy now
        if request.method == 'POST':
            action = request.form.get('action')
            
            if action == 'add_to_cart':
                cursor.execute("""
                    INSERT INTO Cart (UserID, ArtworkID, Quantity)
                    VALUES (%s, %s, 1)
                    ON DUPLICATE KEY UPDATE Quantity = Quantity + 1
                """, (user_id, artwork_id))
                connection.commit()
                return redirect(url_for('view_cart'))
            
            elif action == 'buy_now':
                return redirect(url_for('checkout'))

        cursor.close()
        connection.close()

        return render_template('artwork_detail.html', artwork=artwork, reviews=reviews)
    else:
        return redirect(url_for('login'))


    
@app.route('/register_user', methods=['GET', 'POST'])
def register_user():
    if request.method == 'POST':
        name = request.form['username']
        email = request.form['email']
        password = request.form['password']


        # Connect to the database
        connection = get_db_connection()
        cursor = connection.cursor()

        # Insert the new user into the database
        try:
            cursor.execute("INSERT INTO User (Name, Email, Password, Role) VALUES ( %s, %s, %s, %s)",
                           (name, email, password, 'Buyer'))  
            connection.commit()
            return redirect(url_for('login'))
        except mysql.connector.Error as err:
            return f"Error: {err}"
        finally:
            cursor.close()
            connection.close()

    return render_template('register_user.html')

@app.route('/register_artist', methods=['GET', 'POST'])
def register_artist():
    if request.method == 'POST':
        name = request.form['username']
        email = request.form['email']
        password = request.form['password']
        biography = request.form['biography']
        
        image = request.files['profile_image']
        if image:
                upload_folder = 'static/uploads'
                os.makedirs(upload_folder, exist_ok=True)

                filename = image.filename
                image_path = os.path.join(upload_folder, filename)
                image.save(image_path)


        # Connect to the database
        connection = get_db_connection()
        cursor = connection.cursor()

        try:
            # Insert the new user into the database
            cursor.execute("""
                INSERT INTO User (Name, Email, Password, Role) 
                VALUES (%s, %s, %s, %s)
            """, (name, email, password, 'Artist'))  
            connection.commit()

            # Get the UserID of the newly inserted user
            userid = cursor.lastrowid

            # Insert artist information into the Artist table
            cursor.execute("""
                INSERT INTO Artist (ArtistID, Biography, ProfileImage) 
                VALUES (%s, %s, %s)
            """, (userid, biography, filename))
            connection.commit()

            return redirect(url_for('login'))
        
        except mysql.connector.Error as err:
            return f"Error: {err}"
        finally:
            cursor.close()
            connection.close()

    return render_template('register_artist.html')

@app.route('/change_profile', methods=['GET', 'POST'])
def change_profile():
    if 'user_id' in session and session['role'] == 'Artist':
        if request.method == 'POST':
            name = request.form['name']
            email = request.form['email']
            password = request.form['password']
            
            connection = get_db_connection()
            cursor = connection.cursor()
            cursor.execute("""
                UPDATE user
                SET Name = %s, Email = %s, Password = %s
                WHERE UserID = %s
            """, (name, email, password, session['user_id']))
            connection.commit()
            cursor.close()
            connection.close()
            
            return redirect(url_for('artist_dashboard'))

        return render_template('change_profile.html')
    else:
        return redirect(url_for('login'))

@app.route('/add_new_art', methods=['GET', 'POST'])
def add_new_art():
    if 'user_id' in session and session['role'] == 'Artist':
        if request.method == 'POST':
            title = request.form['title']
            description = request.form['description']
            price = request.form['price']
            medium = request.form['medium']
            style = request.form['style']
            availability = request.form['availability']
            image = request.files['image']
            
            if image:
                upload_folder = 'static/uploads'
                os.makedirs(upload_folder, exist_ok=True)

                filename = image.filename
                image_path = os.path.join(upload_folder, filename)
                image.save(image_path)

                # Save the artwork information in the database
                connection = get_db_connection()
                cursor = connection.cursor()
                cursor.execute("""
                    INSERT INTO Artwork (Title, Description, Price, Medium, Style, Availability, ArtistID, Image)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """, (title, description, price, medium, style, availability, session['user_id'], filename))
                connection.commit()
                cursor.close()
                connection.close()
            
            return redirect(url_for('artist_dashboard'))
        
        return render_template('add_new_art.html')
    else:
        return redirect(url_for('login'))

@app.route('/order_review/<int:order_id>', methods=['GET', 'POST'])
def order_review(order_id):
    if 'user_id' in session:
        user_id = session['user_id']

        if request.method == 'POST':
            rating = request.form.get('rating')
            comment = request.form.get('comment')

            # Ensure the review data is valid
            if rating and comment:
                connection = get_db_connection()
                cursor = connection.cursor(dictionary= True)
                
                # Fetch the ArtworkID for the order
                cursor.execute("""
                    SELECT oi.ArtworkID
                    FROM `order` o
                    JOIN orderitem oi ON o.OrderID = oi.OrderID
                    WHERE o.OrderID = %s
                """, (order_id,))
                artwork_id = cursor.fetchone()
                
                if artwork_id:
                    artwork_id = artwork_id['ArtworkID']

                    # Insert the review into the database
                    cursor.execute("""
                        INSERT INTO Review (BuyerID, ArtworkID, Rating, Comment)
                        VALUES (%s, %s, %s, %s)
                    """, (user_id, artwork_id, rating, comment))
                    connection.commit()
                    
                cursor.close()
                connection.close()

                return redirect(url_for('buyer_order_details'))
            else:
                return "Invalid review data", 400

        else:
            # Fetch order details to show on the review page
            connection = get_db_connection()
            cursor = connection.cursor(dictionary=True)
            cursor.execute("""
                SELECT o.OrderID, o.OrderDate, oi.Quantity, a.Title, oi.Price
                FROM `order` o
                JOIN orderitem oi ON o.OrderID = oi.OrderID
                JOIN Artwork a ON oi.ArtworkID = a.ArtworkID
                WHERE o.OrderID = %s
            """, (order_id,))
            order = cursor.fetchone()
            
            cursor.close()
            connection.close()
            
            if not order:
                return redirect(url_for('buyer_order_details'))

            return render_template('order_review.html', order=order)
    else:
        return redirect(url_for('login'))




@app.route('/view_orders', methods=['GET', 'POST'])
def view_orders():
    if 'user_id' in session and session['role'] == 'Artist':
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        
        if request.method == 'POST':
            order_id = request.form['order_id']
            new_status = request.form['status']
            cursor.execute("""
                UPDATE `order`
                SET Status = %s
                WHERE OrderID = %s
            """, (new_status, order_id))
            connection.commit()

        cursor.execute("""
            SELECT o.OrderID, o.OrderDate, o.TotalAmount, o.Status, oi.ArtworkID, a.Title, oi.Quantity, oi.Price
            FROM `order` o
            JOIN orderitem oi ON o.OrderID = oi.OrderID
            JOIN Artwork a ON oi.ArtworkID = a.ArtworkID
            WHERE a.ArtistID = %s
            ORDER BY o.OrderDate DESC
        """, (session['user_id'],))
        orders = cursor.fetchall()
        
        cursor.close()
        connection.close()

        return render_template('view_orders.html', orders=orders)
    else:
        return redirect(url_for('login'))



@app.route('/add_to_cart/<int:artwork_id>', methods=['POST'])
def add_to_cart(artwork_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user_id = session['user_id']

    # Connect to the database
    connection = get_db_connection()
    cursor = connection.cursor()

    try:
        # Check the availability of the artwork
        cursor.execute("SELECT Availability FROM Artwork WHERE ArtworkID = %s", (artwork_id,))
        artwork = cursor.fetchone()
        
        if not artwork:
            return "Artwork not found!"

        availability = artwork[0]

        if availability <= 0:
            return "Sorry, this artwork is no longer available."

        # Check if the artwork is already in the cart
        cursor.execute("SELECT Quantity FROM Cart WHERE UserID = %s AND ArtworkID = %s", (user_id, artwork_id))
        cart_item = cursor.fetchone()

        if cart_item:
            # Update quantity if already in the cart
            current_quantity = cart_item[0]
            new_quantity = current_quantity + 1

            if new_quantity > availability:
                return "Sorry, you cannot add more of this item to your cart than is available."

            cursor.execute("UPDATE Cart SET Quantity = %s WHERE UserID = %s AND ArtworkID = %s",
                           (new_quantity, user_id, artwork_id))
        else:
            # Add new item to the cart
            cursor.execute("INSERT INTO Cart (UserID, ArtworkID, Quantity) VALUES (%s, %s, %s)",
                           (user_id, artwork_id, 1))

        connection.commit()
        return redirect(url_for('view_cart'))

    except mysql.connector.Error as err:
        return f"Error: {err}"
    finally:
        cursor.close()
        connection.close()

@app.route('/update_cart', methods=['POST'])
def update_cart():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user_id = session['user_id']
    artwork_id = request.form['artwork_id']
    new_quantity = int(request.form['quantity'])

    # Connect to the database
    connection = get_db_connection()
    cursor = connection.cursor()

    try:
        # Check the availability of the artwork
        cursor.execute("SELECT Availability FROM Artwork WHERE ArtworkID = %s", (artwork_id,))
        artwork = cursor.fetchone()

        if not artwork:
            return "Artwork not found!"

        availability = artwork[0]

        if new_quantity > availability:
            return "Sorry, you cannot add more of this item to your cart than is available."

        # Update cart quantity
        if new_quantity <= 0:
            cursor.execute("DELETE FROM Cart WHERE UserID = %s AND ArtworkID = %s", (user_id, artwork_id))
        else:
            cursor.execute("UPDATE Cart SET Quantity = %s WHERE UserID = %s AND ArtworkID = %s",
                           (new_quantity, user_id, artwork_id))

        connection.commit()
        return redirect(url_for('view_cart'))

    except mysql.connector.Error as err:
        return f"Error: {err}"
    finally:
        cursor.close()
        connection.close()




@app.route('/view_cart')
def view_cart():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user_id = session['user_id']

    # Connect to the database
    connection = get_db_connection()
    cursor = connection.cursor()

    try:
        # Retrieve cart items
        cursor.execute("""
            SELECT Artwork.Title, Artwork.Price, Cart.Quantity, (Artwork.Price * Cart.Quantity) AS TotalPrice, Cart.ArtworkID
            FROM Cart
            JOIN Artwork ON Cart.ArtworkID = Artwork.ArtworkID
            WHERE Cart.UserID = %s
        """, (user_id,))
        cart_items = cursor.fetchall()

        # Calculate total amount
        total_amount = sum(item[3] for item in cart_items)

        return render_template('view_cart.html', cart_items=cart_items, total_amount=total_amount)

    except mysql.connector.Error as err:
        return f"Error: {err}"
    finally:
        cursor.close()
        connection.close()



@app.route('/remove_item', methods=['POST'])
def remove_item():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user_id = session['user_id']
    artwork_id = request.form['artwork_id']

    # Connect to the database
    connection = get_db_connection()
    cursor = connection.cursor()

    try:
        # Remove the item from the cart
        cursor.execute("""
            DELETE FROM Cart
            WHERE UserID = %s AND ArtworkID = %s
        """, (user_id, artwork_id))
        connection.commit()

        return redirect(url_for('view_cart'))

    except mysql.connector.Error as err:
        return f"Error: {err}"
    finally:
        cursor.close()
        connection.close()


from flask import Flask, render_template, request, redirect, url_for, session, flash

@app.route('/checkout', methods=['GET', 'POST'])
def checkout():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user_id = session['user_id']

    if request.method == 'POST':
        # Handle form submission
        payment_method = request.form.get('payment_method')

        if not payment_method:
            flash("Please select a payment method.", "error")
            return redirect(url_for('checkout'))

        # Connect to the database
        connection = get_db_connection()
        cursor = connection.cursor()

        try:
            # Insert the order into the 'order' table
            cursor.execute("""
                INSERT INTO `order` (BuyerID, OrderDate, TotalAmount, Status)
                SELECT %s, NOW(), SUM(a.Price * c.Quantity), 'Pending'
                FROM Cart c
                JOIN Artwork a ON c.ArtworkID = a.ArtworkID
                WHERE c.UserID = %s
            """, (user_id, user_id))
            order_id = cursor.lastrowid

            # Insert each cart item into the 'orderitem' table and update the artwork quantity
            cursor.execute("""
                SELECT c.ArtworkID, c.Quantity
                FROM Cart c
                WHERE c.UserID = %s
            """, (user_id,))
            cart_items = cursor.fetchall()

            for item in cart_items:
                artwork_id = item[0]
                quantity_ordered = item[1]

                # Insert the order item
                cursor.execute("""
                    INSERT INTO orderitem (OrderID, ArtworkID, Quantity, Price)
                    SELECT %s, c.ArtworkID, c.Quantity, a.Price
                    FROM Cart c
                    JOIN Artwork a ON c.ArtworkID = a.ArtworkID
                    WHERE c.UserID = %s AND c.ArtworkID = %s
                """, (order_id, user_id, artwork_id))

                # Update the artwork quantity in the Artwork table
                cursor.execute("""
                    UPDATE Artwork
                    SET Availability = Availability - %s
                    WHERE ArtworkID = %s
                """, (quantity_ordered, artwork_id))

            # Record the payment
            cursor.execute("""
                INSERT INTO payment (OrderID, PaymentMethod, PaymentDate, PaymentStatus)
                VALUES (%s, %s, NOW(), 'Completed')
            """, (order_id, payment_method))

            # Clear the user's cart
            cursor.execute("DELETE FROM Cart WHERE UserID = %s", (user_id,))

            # Commit the transaction
            connection.commit()

        except Exception as e:
            # If an error occurs, rollback the transaction
            connection.rollback()
            flash("An error occurred during the order process: " + str(e), "error")
            return redirect(url_for('checkout'))

        finally:
            cursor.close()
            connection.close()

        return redirect(url_for('order_confirmation', order_id=order_id))

    else:
        # Handle GET request: Display the checkout page
        connection = get_db_connection()
        cursor = connection.cursor()

        # Retrieve cart items
        cursor.execute("""
            SELECT a.Title, a.Price, c.Quantity, (a.Price * c.Quantity) AS Total
            FROM Cart c
            JOIN Artwork a ON c.ArtworkID = a.ArtworkID
            WHERE c.UserID = %s
        """, (user_id,))
        cart_items = cursor.fetchall()

        # Calculate total amount
        cursor.execute("""
            SELECT SUM(a.Price * c.Quantity)
            FROM Cart c
            JOIN Artwork a ON c.ArtworkID = a.ArtworkID
            WHERE c.UserID = %s
        """, (user_id,))
        total_amount = cursor.fetchone()[0]

        cursor.close()
        connection.close()

        return render_template('checkout.html', cart_items=cart_items, total_amount=total_amount)


@app.route('/order_confirmation/<int:order_id>', methods=['GET'])
def order_confirmation(order_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user_id = session['user_id']

    # Connect to the database
    connection = get_db_connection()
    cursor = connection.cursor()

    # Retrieve order details
    cursor.execute("""
        SELECT o.OrderID, o.OrderDate, o.TotalAmount, o.Status, p.PaymentMethod, p.TransactionID
        FROM `order` o
        JOIN payment p ON o.OrderID = p.OrderID
        WHERE o.OrderID = %s AND o.BuyerID = %s
    """, (order_id, user_id))
    order_details = cursor.fetchone()

    # Retrieve the order items
    cursor.execute("""
        SELECT a.Title, oi.Quantity, oi.Price
        FROM orderitem oi
        JOIN Artwork a ON oi.ArtworkID = a.ArtworkID
        WHERE oi.OrderID = %s
    """, (order_id,))
    order_items = cursor.fetchall()

    cursor.close()
    connection.close()

    # Check if the order details exist
    if not order_details:
        flash("Order not found or you do not have permission to view this order.", "error")
        return redirect(url_for('index'))

    return render_template('order_confirmation.html', order_details=order_details, order_items=order_items)


  
if __name__ == '__main__':
    app.run(debug=True)